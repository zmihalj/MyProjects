This is my project for the end of my Python course.

The purpose of this program is to showcase what I've learned during my course and apply it in a practical use. 

I chose to create an app that will have your rooms and plants in them and based on pulled data from the internet suggest what to do with them. 