import webbrowser

import calendar
import datetime
import json
import random as rd
import sqlite3
import tkinter as tk
import tkinter.messagebox
import tkinter.filedialog as tkf
from tkinter import ttk
from PIL import Image,ImageTk
import io
import customtkinter as ctk
import matplotlib.pyplot as plt
import pandas as pd
import requests
from matplotlib import style
import webbrowser




root = tk.Tk()

birdsofparadise = ImageTk.PhotoImage(Image.open("slike/birdsofparadise.jpg"))
carantion = ImageTk.PhotoImage(Image.open("slike/carantion.jpg"))
fiddle = ImageTk.PhotoImage(Image.open("slike/fiddle.jpg"))
geranium = ImageTk.PhotoImage(Image.open("slike/geranium.jpg"))
hibiscus = ImageTk.PhotoImage(Image.open("slike/hibiscus.jpg"))
hosta = ImageTk.PhotoImage(Image.open("slike/hosta.jpg"))
peony = ImageTk.PhotoImage(Image.open("slike/peony.jpg"))
sedum = ImageTk.PhotoImage(Image.open("slike/sedum.jpg"))
swisscheese = ImageTk.PhotoImage(Image.open("slike/SwissCheese.jpg"))


def convertToBinaryData(filename):
    with open(filename, 'rb') as file:
        blobData = file.read()
    return blobData

  


lista_imena = ['birdsofparadise.jpg', 'carantion.jpg', 'fiddle.jpg', 'geranium.jpg', 'hibiscus.jpg', 'hosta.jpg', 'peony.jpg', 'sedum.jpg', 'SwissCheese.jpg']
lista_slika = [birdsofparadise,carantion,fiddle,geranium,hibiscus,hosta,peony,sedum,swisscheese]

posude = ['Dnevni boravak prozor','Dnevni boravak kut','Balkon prednji','Balkon kut prednji','Balkon straznji','Radna Soba','Kuhinja','Vrt','Spavaca soba','Djecja soba']

def signup():
    sign_window = tk.Toplevel(root)
    sign_window.title('Sign up')
    sign_window.geometry('400x400')

    title_label = tk.Label(sign_window, text='Sign Up', font=(font_slova, 25))
    title_label.pack(pady=20)

    email_label = tk.Label(sign_window, text='Email', font=(font_slova, 12))
    email_label.pack(pady=5)

    email_entry = tk.Entry(sign_window, relief=tk.RAISED, textvariable=email_var)
    email_entry.pack(pady=5)

    username_label = tk.Label(sign_window, text='Username', font=(font_slova, 12))
    username_label.pack(pady=5)

    username_entry = tk.Entry(sign_window, relief=tk.RAISED, textvariable=kor_ime_var)
    username_entry.pack(pady=5)

    password_label = tk.Label(sign_window, text='Password', font=(font_slova, 12))
    password_label.pack(pady=5)

    password_entry = tk.Entry(sign_window, relief=tk.RAISED, textvariable=sifra_var, show='*')
    password_entry.pack(pady=5)

    submit_button = tk.Button(sign_window, text='Sign Up', font=(font_slova, 12), command=save_korisnik)
    submit_button.pack(pady=10)

    exit_button = tk.Button(sign_window, text='Exit', font=(font_slova, 12), command=sign_window.destroy)
    exit_button.pack(pady=10)

    sign_window.update_idletasks()
    width = sign_window.winfo_width()
    height = sign_window.winfo_height()
    x = (sign_window.winfo_screenwidth() // 2) - (width // 2)
    y = (sign_window.winfo_screenheight() // 2) - (height // 2)
    sign_window.geometry('{}x{}+{}+{}'.format(width, height, x, y))

def create_db_users():
    conn= sqlite3.connect('PyFloraUsers.db')
    c=conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS Users(email TEXT PRIMARY KEY NOT NULL UNIQUE, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL)")
    conn.commit()
    conn.close()
create_db_users()

def save_korisnik():
    email = email_var.get()
    kor_ime = kor_ime_var.get()
    sifra=sifra_var.get()
    
    conn= sqlite3.connect('PyFloraUsers.db')
    c=conn.cursor()
    
    c.execute("INSERT INTO Users(email,username,password) VALUES (?,?,?)",(email,kor_ime,sifra)) 
    conn.commit()
    print('Korisnik spremljen')
    tkinter.messagebox.showinfo('Bravo','Uspjesno ste napravili racun')

    email_var.get('')
    kor_ime_var.get('')
    sifra_var.get('')


    
def novi_prozor():
    
    unos_window = tk.Toplevel(bg='white smoke')
    unos_window.title('Biljke')
    unos_window.geometry('800x600')


    lbl_biljke = tk.Label(unos_window,text='Biljke',font=(font_slova,25),fg='black',bg='white smoke')
    lbl_biljke.grid(row=0,column=1,padx=100,pady=20)
    profil_btn = ctk.CTkButton(unos_window,text='Moj Profil',corner_radius=3,border_color='black',border_width=1,command=my_profile)
    profil_btn.grid(row=0,column=2,padx=20,pady=10,sticky='e')

    
    sync_btn = ctk.CTkButton(unos_window,text='Sync',corner_radius=3,border_color='black',border_width=1,command=sync)
    sync_btn.grid(row=0,column=0,padx=10,pady=10)

    items_listbox = tk.Listbox(unos_window,listvariable=lista_biljaka_var,bg='grey',fg='black',font=(font_slova,15),selectmode=tk.SINGLE)
    items_listbox.grid(row=1,column=0,rowspan=2)



    def selected_item():
        
        global prikaz,prikaz_id,prikaz_ime,prava_slika

      
        def search_on_google():
            selected_plant =prikaz_ime.cget('text').split(': ')[1]
            if selected_plant.endswith('.jpg'):
                selected_plant = selected_plant[:-4]
            elif selected_plant.endswith('.jpeg'):
                selected_plant = selected_plant[:-5]
            search_url = f'https://www.google.com/search?q={selected_plant}'
            webbrowser.open_new_tab(search_url)

        for i in items_listbox.curselection():
            izbor=items_listbox.get(i)
            konekcija = sqlite3.connect('Posude_i_biljke.db')
            biljke_frm = tk.LabelFrame(unos_window,text='Biljke detaljnije',padx=10,pady=10,bg='grey')
            biljke_frm.grid(row=1,column=1,columnspan=2,rowspan=2,sticky='Ne')

            cur = konekcija.cursor()

            cur.execute('SELECT * From Biljke WHERE ime_biljke = ?',(izbor,))
            sve = cur.fetchall()

            for red in sve:
                slika = red[2]
                ime = red[1]
                id = red[0]

                imageStream = io.BytesIO(slika)
                imageFile = Image.open(imageStream)

                prava_slika = ImageTk.PhotoImage(imageFile)

                prikaz_ime = tk.Label(biljke_frm,text=f'Ime biljke: {ime}',font=(font_slova,12),bg='white smoke')
                prikaz_ime.pack(side=tk.TOP)

                prikaz_id = tk.Label(biljke_frm,text=f'ID: {id}',font=(font_slova,12),bg='white smoke')
                prikaz_id.pack(side=tk.TOP)

                prikaz = tk.Label(biljke_frm,image=prava_slika,bg='white smoke')
                prikaz.pack(padx=10,pady=10,ipadx=10,ipady=10,fill='both')

                search_btn = ctk.CTkButton(biljke_frm,text='Search on Google',command=search_on_google,corner_radius=3,border_color='black',border_width=1)
                search_btn.pack(pady=10,ipadx=10,ipady=10,fill='both')

                clr_crn_btn = ctk.CTkButton(unos_window,text='Clear',command=clear_screen,corner_radius=3,border_color='black',border_width=1)
                clr_crn_btn.grid(row=3,column=1,padx=10,pady=10)

                

    show_btn = ctk.CTkButton(unos_window,text='Prikazi biljku',command=selected_item,corner_radius=3,border_color='black',border_width=1)
    show_btn.grid(row=3,column=0,padx=10,pady=10)


    def dodaj_biljku_posudi():
        
        add_biljka = tk.Toplevel(bg='grey')
        add_biljka.title('Dodaj biljku')
        add_biljka.geometry('500x500')
        dodaj_bilj_lbl = tk.Label(add_biljka,text='Izaberi biljku: ',font=(font_slova,12),bg='grey')
        dodaj_bilj_lbl.grid(row=0,column=0,padx=10,pady=10)
        baza = sqlite3.connect('Posude_i_biljke.db')
        cur=baza.cursor()
        cur.execute('SELECT * FROM Biljke')
        sve = cur.fetchall()
        biljke=[]
        for i in sve:
            biljke.append(i[1])
        baza.close()   
        biljke_box = ttk.Combobox(add_biljka,values=biljke,width=30,textvariable=izbor_biljke,font=(font_slova,12))
        biljke_box.current(0)
        biljke_box.grid(row=0,column=1,padx=10,pady=10)

        baza2 = sqlite3.connect('Posude_i_biljke.db')
        cur2=baza2.cursor()
        cur2.execute('SELECT * FROM Biljke_Posude')
        posude1=[]

        zauzete_posude = cur2.fetchall()
        lista_zauzetih = []
        for z in zauzete_posude:
            lista_zauzetih.append(z[1])
            

        for ime in posude:
                if ime not in lista_zauzetih:
                    posude1.append(ime)
                    
        
        dodaj_pos_lbl = tk.Label(add_biljka,text='Odaberi posudu',font=(font_slova,12),bg='grey')
        dodaj_pos_lbl.grid(row=1,column=0,padx=10,pady=10)

        posude_box = ttk.Combobox(add_biljka,values=posude1,width=30,textvariable=izbor_posude,font=(font_slova,12))
        posude_box.current(0)
        posude_box.grid(row=1,column=1,padx=10,pady=10)

      

        def add_to_baza():
            pos = izbor_posude.get()
            bilj = izbor_biljke.get()

            with sqlite3.connect('Posude_i_biljke.db') as con:
                cur = con.cursor()
                cur.execute('INSERT INTO Biljke_Posude(ime_posude,ime_biljke) VALUES(?, ?)', (pos, bilj))
                con.commit()

            tkinter.messagebox.showinfo('Biljka dodana!', 'Uspješno dodana biljka u posudu')

        sbm_btn = ctk.CTkButton(add_biljka,text='Potvrdi',command=add_to_baza,corner_radius=3,border_color='red',border_width=2)
        sbm_btn.grid(row=2,column=1,padx=150,pady=10)
    
    dodaj_btn = ctk.CTkButton(unos_window,text='Dodaj biljku',command=dodaj_biljku_posudi,corner_radius=3,border_color='red',border_width=2)
    dodaj_btn.grid(row=4,column=0,padx=10,pady=10)

    def statistika():
        stat_window = tk.Toplevel(bg='grey')
        stat_window.title('Informacije i statistika')
        stat_window.geometry('500x500')
        global posuda_za_stat

        posuda_za_stat = tk.StringVar()

        con = sqlite3.connect('Posude_i_biljke.db')
        cur = con.cursor()
        cur.execute('SELECT * FROM Biljke_Posude')
        sve = cur.fetchall()
        posude=[]
        for item in sve:
            posude.append(item[1])
        
        izbor_za_stat = ctk.CTkComboBox(stat_window,values=posude,variable=posuda_za_stat,border_color='white',border_width=1,corner_radius=3,width=300)
        izbor_za_stat.set('Izaberi posudu')
        izbor_za_stat.grid(row=0,column=0,padx=20,pady=20)

        def potvrdi():
            con = sqlite3.connect('Posude_i_biljke.db')
            cur = con.cursor()
            cur.execute('SELECT * FROM Posude WHERE ime_posude=?',(posuda_za_stat.get(),))
            podaci = cur.fetchall()

            df=pd.DataFrame(podaci,columns=['ime_posude','temp','humidity','dt','day','svjetlost'])

            style.use('ggplot')

            def temp_stat():
                
                
                ax = df.plot(ylabel='Temperatura (°C)', xlabel='Vrijeme', x='day', y='temp', 
                            title='Temperatura zraka', linewidth=2)
                
                plt.xticks(rotation=20)
                
                plt.grid(color='gray', linestyle='--', linewidth=0.5)
           
                plt.show()

            show_temp_btn = ctk.CTkButton(stat_window, text='Temperatura', command=temp_stat,
                                        corner_radius=3, border_color='black', border_width=1)
            show_temp_btn.grid(row=1, column=0, padx=10, pady=10)

            def hum_stat():
    
                
                ax = df.plot(ylabel='Vlaznost (%)', xlabel='Vrijeme', x='day', y='humidity', 
                            title='Vlaznost zemlje', linewidth=2)
                plt.xticks(rotation=20)
                plt.grid(color='gray', linestyle='--', linewidth=0.5)
                plt.show()

            show_hum_btn = ctk.CTkButton(stat_window, text='Vlaznost', command=hum_stat,
                                        corner_radius=3, border_color='black', border_width=1)
            show_hum_btn.grid(row=2, column=0, padx=10, pady=10)


            def del_biljka():
                cur.execute('DELETE FROM Biljke_Posude WHERE ime_posude=?',(posuda_za_stat.get(),))
                tkinter.messagebox.showinfo('Uspjeh',f'Biljka vise nije u posudi {posuda_za_stat.get()}')
                con.commit()
                stat_window.destroy()

                                    

            del_biljku = ctk.CTkButton(stat_window,text='Isprazni posudu',command=del_biljka,corner_radius=3,border_color='black',border_width=1,bg_color='red')
            del_biljku.grid(row=2,column=1,padx=10,pady=10)

            def svjetlost_stat():
                zbroj = df['svjetlost'].value_counts()

                plt.pie(zbroj)
                plt.title('Svjetlost')
                plt.legend(df['svjetlost'])
                plt.show()

            show_light_btn = ctk.CTkButton(stat_window,text='Svjetlost',command=svjetlost_stat,corner_radius=3,border_color='black',border_width=1)
            show_light_btn.grid(row=3,column=0,padx=10,pady=10)
            

            
            
            
        potvrdi_btn = ctk.CTkButton(stat_window,text='Potvrdi',command=potvrdi,border_color='grey',border_width=1,corner_radius=3)
        potvrdi_btn.grid(row=0,column=1,padx=10,pady=10)

    stat_btn = ctk.CTkButton(unos_window,text='Statistika',command=statistika,corner_radius=3,border_color='grey',border_width=1)
    stat_btn.grid(row=4,column=1,padx=10,pady=10)


    def clear_screen():
        prikaz_ime.pack_forget()
        prikaz_id.pack_forget()
        prikaz.pack_forget()


    





conn = sqlite3.connect('Posude_i_biljke.db')
conn.execute('PRAGMA foreign_keys=1')
cur = conn.cursor()

cur.execute('''CREATE TABLE IF NOT EXISTS Biljke_Posude(
            id INTEGER PRIMARY KEY,
            ime_posude TEXT NOT NULL,
            ime_biljke TEXT NOT NULL,
            FOREIGN KEY(ime_posude) REFERENCES Posude(ime_posude),
            FOREIGN KEY(ime_biljke) REFERENCES Biljke(ime_biljke))''')
conn.close()
   


    

def my_profile():
    profil_window = tk.Toplevel(bg='white smoke') 
    profil_window.title('My Profile')
    profil_window.geometry('500x500')

    global email_var
    username_var = tk.StringVar()
    password_var = tk.StringVar()
    email_var = tk.StringVar()
    def update_kor_podatke():
        update_lvl = tk.Toplevel(profil_window, bg='white')
        update_lvl.geometry('400x400')
        update_lvl.title('Azuriranje korisnika')

        global novo_kor_ime_var
        global nova_sifra_var

        novo_kor_ime_var = tk.StringVar()
        nova_sifra_var = tk.StringVar()

        update_lbl = tk.Label(update_lvl, text='Azuriranje podataka', font=(font_slova, 20), fg='#007aff', bg='white')
        update_lbl.pack(pady=(20, 10))

        novo_kor_ime_frame = tk.Frame(update_lvl, bg='white')
        novo_kor_ime_frame.pack(pady=(20, 10))

        lbl_novo_kor_ime = tk.Label(novo_kor_ime_frame, text='Unesite novo korisnicko ime', font=(font_slova, 12),
                                    fg='#007aff', bg='white')
        lbl_novo_kor_ime.pack(side='left')

        ent_novo_kor_ime = tk.Entry(novo_kor_ime_frame, textvariable=novo_kor_ime_var, bg='#f2f2f2', fg='black', relief='flat',
                                    font=(font_slova, 12), width=25, borderwidth=1)
        ent_novo_kor_ime.pack(side='right')

        nova_sifra_frame = tk.Frame(update_lvl, bg='white')
        nova_sifra_frame.pack(pady=(20, 10))

        lbl_nova_sifra = tk.Label(nova_sifra_frame, text='Unesite novu sifru', font=(font_slova, 12), fg='#007aff',
                                bg='white')
        lbl_nova_sifra.pack(side='left')

        ent_nova_sifra = tk.Entry(nova_sifra_frame, textvariable=nova_sifra_var, bg='#f2f2f2', fg='black', relief='flat',
                                font=(font_slova, 12), width=25, borderwidth=1)
        ent_nova_sifra.pack(side='right')

        azuriraj_btn = tk.Button(update_lvl, text='Azuriraj', bg='#007aff', fg='white', font=(font_slova, 12),
                                command=azuriraj_podatke, width=15, height=2, bd=0)
        azuriraj_btn.pack(pady=(20, 10))

        exit_btn = tk.Button(update_lvl, text='Exit', bg='#f2f2f2', fg='black', font=(font_slova, 12),
                            command=update_lvl.destroy, width=15, height=2, bd=0)
        exit_btn.pack(pady=(10, 20)) 


    def submit():
        kor_ime = username_var.get()
        sifra= password_var.get()
        
        conn= sqlite3.connect('PyFloraUsers.db')
        c=conn.cursor()
        c.execute("SELECT * FROM Users WHERE username=? AND password=?",(kor_ime,sifra))
        provjera = c.fetchone()

        if provjera:
            lbl_user= tk.Label(profil_window,text=f'Email: {provjera[0]}',font=(font_slova,15),bg='grey',fg='black')
            lbl_user.grid(row=4,column=0)

            lbl_username= tk.Label(profil_window,text=f'Korisnicko ime: {provjera[1]}',font=(font_slova,15),bg='grey',fg='black')
            lbl_username.grid(row=5,column=0)

            lbl_pass= tk.Label(profil_window,text=f'Lozinka: {provjera[2]}',font=(font_slova,15),bg='grey',fg='black')
            lbl_pass.grid(row=6,column=0)
        
                
        else:
            tkinter.messagebox.showerror('Ups','Niste korisnik')


    username_label = tk.Label(profil_window, text='Username:', font=('Helvetica', 12), bg='white smoke')
    username_label.grid(row=0, column=0, pady=10, padx=10)

    username_entry = tk.Entry(profil_window, textvariable=username_var, font=('Helvetica', 12), bg='white', fg='black')
    username_entry.grid(row=0, column=1, pady=10, padx=10)

    password_label = tk.Label(profil_window, text='Password:', font=('Helvetica', 12), bg='white smoke')
    password_label.grid(row=1, column=0, pady=10, padx=10)

    password_entry = tk.Entry(profil_window, textvariable=password_var, font=('Helvetica', 12), bg='white', fg='black', show='*')
    password_entry.grid(row=1, column=1, pady=10, padx=10)

    email_label = tk.Label(profil_window, text='Email:', font=('Helvetica', 12), bg='white smoke')
    email_label.grid(row=2, column=0, pady=10, padx=10)

    email_entry = tk.Entry(profil_window, textvariable=email_var, font=('Helvetica', 12), bg='white', fg='black')
    email_entry.grid(row=2, column=1, pady=10, padx=10)

    update_button = tk.Button(profil_window, text='Update Information', font=('Helvetica', 12), bg='cyan', command=update_kor_podatke)
    update_button.grid(row=3, column=1, pady=10, padx=10)

    delete_button = tk.Button(profil_window, text='Delete User', font=('Helvetica', 12), bg='red', fg='white', command=delete_user)
    delete_button.grid(row=4, column=0, pady=10, padx=10)

    submit_button = tk.Button(profil_window, text='Submit', font=('Helvetica', 12), bg='green2', command=submit)
    submit_button.grid(row=3, column=0, pady=10, padx=10)

    exit_button = tk.Button(profil_window, text='Exit', font=('Helvetica', 12), bg='black', fg='white', command=profil_window.destroy)
    exit_button.grid(row=4, column=1, pady=10, padx=10)


    

def azuriraj_podatke():


            database_name = 'PyFloraUsers.db'

            update_table_query = '''UPDATE Users
                                    SET username=?,
                                        password=?
                                    WHERE email=?
            '''

            novi_username = novo_kor_ime_var.get()
            nova_sifra = nova_sifra_var.get()
            email =email_var.get()

            try: 
                sqliteConnection = sqlite3.connect(database_name)
                cursor = sqliteConnection.cursor()
                print("Baza je uspješno kreirana!")
                cursor.execute(update_table_query,(novi_username,nova_sifra,email))
                sqliteConnection.commit()
                print("Kreirana je nova tablica Users")
                cursor.close()
                print("Resursi objekta cursor uspješno su otpušteni")

            except sqlite3.Error as error:
                print("Dogodila se pogreška prilikom spajanja na SQLite: ", error)

            finally:
                if sqliteConnection:
                    sqliteConnection.close()
                    print("SQL konekcija je uspješno zatvorena!")    
def delete_user():
    database_name = 'PyFloraUsers.db'
    delete_table_query = '''DELETE FROM Users
                            WHERE email=?
                        '''
    email =email_var.get()
    
    try: 
        with sqlite3.connect(database_name) as conn:
            cursor = conn.cursor()
            cursor.execute(delete_table_query, (email,))
            conn.commit()
            tkinter.messagebox.showinfo('Uspjeh', 'Korisnicki profil izbrisan!')
    
    except sqlite3.Error as error:
        print("Dogodila se pogreška prilikom spajanja na SQLite: ", error)
        tkinter.messagebox.showerror('Greska', error)
        
    else:
        print("Baza je uspješno kreirana!")
        
    finally:
        if conn:
            conn.close()
            print("SQL konekcija je uspješno zatvorena!")


def provjera_korisnik():
    ime = kor_ime_var.get()
    sifra=sifra_var.get()

    conn= sqlite3.connect('PyFloraUsers.db')
    c=conn.cursor()
    c.execute("SELECT * FROM Users WHERE username=? AND password=?",(ime,sifra))
    provjera = c.fetchone()
    if provjera:
        tkinter.messagebox.showinfo('Success',f'Welcome {ime}')

        kor_ime_var.set('')
        sifra_var.set('')
        dalje.config(state='normal')

    else:
        tkinter.messagebox.showwarning('Ne! ','Niste korisnik')
        dalje.config(state='disabled')  
    
    kor_ime_var.set('')
    sifra_var.set('')

            
def set_prikaz_lozinke():
    if switch_sifra.get()== 'prikazi':
        entry_sifra.config(show="")
    else:
        entry_sifra.config(show='*')

profin_api='c94a2499bf7fc730cc0e2d7777112526'   
lat = 43.508133
lon = 16.440193



lat = [44.86833,45.23878,45.33673,45.09485,45.40788,45.40837,45.27602,45.12284,45.14391,44.95896,]
lon = [13.84806,13.93497,13.82821,14.12319,13.96559,13.65914,13.71887,13.83850,13.90868,13.85134]
#current time
current_time = datetime.datetime.utcnow()
unix_time = calendar.timegm(current_time.utctimetuple())
unix_dates=[unix_time - 7200,unix_time - 3600,unix_time]


def get_weather_data(current_data, city_name):
    temp = round(current_data['temp'] - 273.15, 2)
    humidity = current_data['humidity']
    dt = current_data['dt']
    sunrise = current_data['sunrise']
    sunset = current_data['sunset']
    description = current_data['weather'][0]['description']

    if sunrise < unix_time < sunset:
        svjetlost = '80-100%' if description == 'clear sky' else '40-80%'
    else:
        svjetlost = '0-40%'

    return [temp, humidity, dt, city_name, datetime.datetime.fromtimestamp(dt).strftime('%Y-%m-%d %H:%M:%S'), svjetlost]


def sync():
    conn = sqlite3.connect('Posude_i_biljke.db')
    data_frames = []

    for pos, lat_i, lon_i in zip(posude, lat, lon):
        pos_url = f'http://api.openweathermap.org/data/2.5/onecall/timemachine?lat={lat_i}&lon={lon_i}&dt={unix_time}&appid={profin_api}'
        pos_result = json.loads(requests.get(pos_url).text)
        pos_data = get_weather_data(pos_result['current'], pos)
        data_frames.append(pos_data)

    headings = ['temp', 'humidity', 'dt', 'ime_posude', 'day', 'svjetlost']
    data_frame = pd.DataFrame(data_frames, columns=headings)

    data_frame.to_sql('Posude', conn, if_exists='append', index=False)


    
def baza_posude():

        baza = sqlite3.connect('Posude_i_biljke.db')
        cursor = baza.cursor()
        cursor.execute('SELECT COUNT(*) FROM Biljke')
        broj= cursor.fetchone()[0]
        if broj<9:
            baza.execute('CREATE TABLE IF NOT EXISTS Posude(ime_posude TEXT NOT NULL,temp REAL, humidity REAL,dt INTEGER, day TEXT,svjetlost TEXT NOT NULL)')
            baza.execute('CREATE TABLE IF NOT EXISTS Biljke(biljka_id INTEGER PRIMARY KEY AUTOINCREMENT,ime_biljke TEXT NOT NULL,slika BLOB)')

            for ime in lista_imena:
                
                baza.execute('INSERT INTO Biljke(ime_biljke,slika) Values(?,?)',(ime,convertToBinaryData('slike/'+ime )))
            baza.commit()



baza_posude()
    





lista_biljaka_var = tk.Variable(value=lista_imena)
sifra_var = tk.StringVar()
kor_ime_var = tk.StringVar()
sakrij_lozinku = tk.StringVar()
prikazi_lozinku_var = tk.StringVar()
email_var = tk.StringVar()
prikazi_lozinku_var.set('Show')
izbor_biljke = tk.StringVar()
izbor_posude = tk.StringVar()



root.title('AppBiljke')
ikonica = tk.PhotoImage(file='ikona1.png')
root.iconphoto(True, ikonica)

root.geometry('800x600')
root.attributes('-alpha', 1)  # set window opacity

bg_label = tk.Label(root, image=ikonica, bd=0, highlightthickness=0)
bg_label.place(relx=0.5, rely=0.5, anchor='center')

font_slova = 'Helvetica'
main_label = tk.Label(root, text='Login', fg='black', font=(font_slova, 25))
main_label.place(relx=0.5, rely=0.3, anchor='center')

ime_label = tk.Label(root, text='Username', fg='black', font=(font_slova, 15))
ime_label.place(relx=0.4, rely=0.4, anchor='center')
sifra_label = tk.Label(root, text='Password', fg='black', font=(font_slova, 15))
sifra_label.place(relx=0.4, rely=0.5, anchor='center')
entry_ime = tk.Entry(root, relief=tk.RAISED, textvariable=kor_ime_var, font=(font_slova, 12))
entry_ime.place(relx=0.6, rely=0.4, anchor='center')
entry_sifra = tk.Entry(root, relief=tk.RAISED, textvariable=sifra_var, show='*', font=(font_slova, 12))
entry_sifra.place(relx=0.6, rely=0.5, anchor='center')

switch_sifra = ctk.CTkSwitch(root, text='Hide Password', command=set_prikaz_lozinke, variable=prikazi_lozinku_var, onvalue='Show', offvalue='Hide')
switch_sifra.place(relx=0.5, rely=0.6, anchor='center')

login= tk.Button(root, text='Login', font=(font_slova, 10), command=provjera_korisnik)
login.place(relx=0.5, rely=0.7, anchor='center')

signup = tk.Button(root, text='Sign Up', font=(font_slova, 10), command=signup)
signup.place(relx=0.5, rely=0.8, anchor='center')
dalje = tk.Button(root, text='Dalje', font=(font_slova, 10), bg='dark grey', state='disabled', command=novi_prozor)
dalje.place(relx=0.5, rely=0.9, anchor='center')

root.mainloop()
